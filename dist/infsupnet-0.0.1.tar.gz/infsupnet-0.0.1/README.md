# InfSupNet: a package for solving PDEs

